#ifndef DECODE_H
#define DECODE_H

#include "types.h" // Contains user defined types

#define EXT_SIZE 4
#define M_SECRET_BUF_SIZE 1
#define M_IMAGE_BUF_SIZE (M_SECRET_BUF_SIZE * 8)
#define FILE_SUFFIX 4
#define MAX_MAGIC_SIZE 4

/* 
 * Structure to store information required for
 * decoding data from stegged image file to text file
 * Info about output and intermediate data is
 * also stored
 */

typedef struct _DecodeInfo
{
   /* Stego Image Info */
   char *ipstego_image_fname;
   FILE *fptr_ipstego_image;
   char stego_image_data[M_IMAGE_BUF_SIZE];

   /* Output Decoded Secret File Info */
   char *temp_decode_fname;
   char *decode_fname;
   FILE *fptr_decode;
   int ext_size;
   char magic_string[MAX_MAGIC_SIZE];
   char secret_extn[FILE_SUFFIX+1];
   char character;
   int flag;
   int decode_file_size;
} DecodeInfo;

/* Decoding function prototypes */

/* Read and validate Decode args from argv */
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo);

/* Perform the decoding */
Status do_decoding(DecodeInfo *decInfo);

/* Get File pointers for i/p and o/p files */
Status open_files_for_decoding(DecodeInfo *decInfo);

/* Decode a byte from LSB of image data array */
Status decode_byte_from_lsb(char *image_buffer);

/* Decode LSB bit from byte of image data */
Status decode_lsb_bit(char *image_buffer, char *decode_image_byte_data);

/* Decode function, which does the real decoding */
Status decode_magic_string_from_image(int size, DecodeInfo *decInfo);

/* Decode extension of file size for decode file */
Status decode_extn_and_file_size(int *size, DecodeInfo *decInfo);

/* Decode size of ouput decode file */
Status decode_secret_file_extn(int ext_size, DecodeInfo *decInfo);

/* Output file extension check */
Status output_file_extn_check(DecodeInfo *decInfo);

/* Decode function, which does the real decoding */
Status decode_secret_data(int size, DecodeInfo *decInfo);

/* closing files */
Status closing_files(DecodeInfo *decInfo);
#endif
