/* Including required files */
#include<stdio.h>
#include <string.h>
#include "decode.h"
#include "types.h"
#include "common.h"

/*
 * Get File pointers for i/p and o/p files
 * Inputs: Stego src Image file, secret file name
 * Output: FILE pointer for above files
 * Return value: e_success or e_failure, on file errors
 */

Status open_files_for_decoding(DecodeInfo *decInfo)
{
    // Stego src file
    decInfo->fptr_ipstego_image = fopen(decInfo->ipstego_image_fname, "r");
    // Do Error handling
    if(decInfo->fptr_ipstego_image == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->ipstego_image_fname);

    	return e_failure;
    }
    return e_success;
}

Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo)
{
    //validating input files
    if(argv[2] == NULL)
      return e_failure;

    else if(strstr(argv[2],".bmp"))
     
           decInfo -> ipstego_image_fname = argv[2];
    else 
         return e_failure;
     
    if(argv[3] == NULL)
        decInfo->flag=1;
    else
        decInfo -> temp_decode_fname = argv[3];
   
   return e_success;
}

Status decode_byte_from_lsb(char *image_buffer)
{
    for(int i = 0; i < 8; i++)
    {
      image_buffer[i] =(image_buffer[i] & 1);
    }
    return e_success;
}

Status decode_lsb_bit(char *image_buffer, char *decode_image_byte_data)
{
    *decode_image_byte_data = 0;
    for(int i=0;i<8;i++)
    {
        *decode_image_byte_data = (image_buffer[i] << (7-i)) | *decode_image_byte_data;
    }
    
    return e_success;
}


Status decode_magic_string_from_image(int size, DecodeInfo *decInfo)
{
    char str[size+1];
    for(int i = 0; i < size; i++)
    {
        fread(decInfo -> stego_image_data, 8, 1, decInfo -> fptr_ipstego_image);
        decode_byte_from_lsb(decInfo -> stego_image_data);
        decode_lsb_bit(decInfo -> stego_image_data, &decInfo -> character);
        str[i]=decInfo->character;
    }
    str[size]='\0';
    //decoded magic string from stego image
    strcpy(decInfo->magic_string,str);
    //comparing magic string if equal or not
    if(strcmp(MAGIC_STRING,decInfo->magic_string)==0)
        return e_success;
    else
        return e_failure;
}


Status decode_extn_and_file_size(int *size, DecodeInfo *decInfo)
{
    //decoding integer size from 32 bytes of stego image
   char str[32];
   *size=0;
//decoding size from lsb
   fread(str, 32, 1, decInfo -> fptr_ipstego_image);

   for(int i=0; i<32 ; i++)
   {
      str[i]=(str[i] & 1);
   }
   for(int i=0; i<32 ; i++)
   {
      *size= (str[i] << (31-i)) | *size;
   }
    return e_success;
}

Status decode_secret_file_extn(int ext_size, DecodeInfo *decInfo)
{
    char ext[ext_size+1];
    for(int i = 0; i < ext_size; i++)
    {
        fread(decInfo -> stego_image_data, 8, 1, decInfo -> fptr_ipstego_image);
        decode_byte_from_lsb(decInfo -> stego_image_data);
        decode_lsb_bit(decInfo -> stego_image_data, &decInfo -> character);
        ext[i]=decInfo->character;
    }
    ext[ext_size]='\0';
    //decoded output file extension stored in stego image
    strcpy(decInfo->secret_extn,ext);
    return e_success;
}

Status output_file_extn_check(DecodeInfo *decInfo)
{ 
    //output file check
    char tmp[20]= "decode";
    if(decInfo->flag==1)
    {
        //if file name not given storing default name
       strcat(tmp, decInfo->secret_extn);  
       decInfo->decode_fname = tmp;      
       printf("Output file not mentioned storing with default name\n");
    }
    else if(strstr(decInfo->temp_decode_fname, decInfo->secret_extn))
    {
        //if file name provided checking extension
        decInfo->decode_fname = decInfo->temp_decode_fname;
        printf("Output file mentioned with correct extension\n");
    }
    else
    {
        //if wrong name given storing default
        strcat(tmp, decInfo->secret_extn);        
        decInfo->decode_fname = tmp;      
        printf("Output file not mentioned with correct extension, storing default name\n");
    }
   
    //opening decode txt file to write decoded data
    decInfo->fptr_decode = fopen(decInfo->decode_fname, "w");
    // Do Error handling
    if (decInfo->fptr_decode == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->decode_fname);

    	return e_failure;
    }
    //printf("Opened %s file to write\n",decInfo->decode_fname);
    // No failure return e_success
    return e_success;
}

Status decode_secret_data(int size, DecodeInfo *decInfo)
{
    char str[size];
    for(int i = 0; i < size; i++)
    {
        fread(decInfo -> stego_image_data, 8, 1, decInfo -> fptr_ipstego_image);
        decode_byte_from_lsb(decInfo -> stego_image_data);
        decode_lsb_bit(decInfo -> stego_image_data, &decInfo -> character);
        str[i]=decInfo->character;
        //writing to output file character by character
        fwrite(&decInfo -> character, 1,1, decInfo -> fptr_decode);
    }
    return e_success;
}

//function for closing files
Status closing_files(DecodeInfo *decInfo)
{
    fclose(decInfo->fptr_ipstego_image);
    fclose(decInfo->fptr_decode);
    return e_success;
}

/* do_decoding function to call other functions for decoding operation */
Status do_decoding(DecodeInfo *decInfo)
{
    if(open_files_for_decoding(decInfo) == e_success){
        printf("INFO: Opening required files\n");
        //pointing file pointer to next byte of 54 byte header
        fseek(decInfo->fptr_ipstego_image, 54, SEEK_SET);
        //Decoding magic string and comparing
        if(decode_magic_string_from_image(strlen(MAGIC_STRING), decInfo) == e_success){ 
            printf("INFO: Decoded magic string successfully and it is matching\n");
        }
        else{
            printf("ERROR: Decoded magic string not matching\n");
            return e_failure;
        }
        if(decode_extn_and_file_size(&decInfo->ext_size, decInfo)==e_success){
            printf("INFO: Decoded file extension size successfully\n");
            if(decInfo->ext_size==decInfo->ext_size){
                printf("INFO: Decoded file extension size matching with given size\n");    
                if(decode_secret_file_extn(decInfo->ext_size, decInfo)==e_success){
                    printf("INFO: Decoded file extension for output file successfully\n");
                    if(output_file_extn_check(decInfo)==e_success){
                        printf("INFO: Output file opened for decoding\n");
                        if(decode_extn_and_file_size(&decInfo->decode_file_size,decInfo)==e_success){
                            printf("INFO: Decoded output file size successfully\n");
                            if(decode_secret_data(decInfo->decode_file_size,decInfo)==e_success){
                                printf("INFO: Decoded secret data successfully\n");
                                if(closing_files(decInfo)==e_success){
                                    printf("*****Decoding completed*****\n");
                                    return e_success;
                                }
                                else{
                                    printf("ERROR: Failed to close files\n");
                                    return e_failure;
                                }
                                return e_success;
                            }
                            else{
                                printf("ERROR: Failed to extract secret data\n");
                                return e_failure;
                            }
                        }
                        else{
                            printf("ERROR: Failed to decode output file size\n");
                            return e_failure;
                        }
                    } 
                    else{
                    printf("ERROR: Failed to open output file\n");
                    return e_failure;
                    }
                }
                else{
                    printf("ERROR: Failed to decode file extension for output file\n");
                    return e_failure;
                  } 
            }
            else{
                printf("ERROR: Decoded file extension size not matching with given size\n");
                return e_failure;
            }
        }
        else{
            printf("ERROR: Failed to decode file extension size\n");
            return e_failure;
        }
    }
    else{
       printf("ERROR: Failed to open files\n");
       return e_failure;
    }
}
