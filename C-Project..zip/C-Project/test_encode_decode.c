#include <stdio.h>
#include<string.h>
#include "encode.h"
#include "types.h"
#include "decode.h"

int main(int argc,char*argv[])
{
    EncodeInfo encInfo;
    uint img_size;
    if(check_operation_type(argv)== e_encode){
        printf("Selected encoding\n");
        //Structure for encoding
        EncodeInfo encInfo;
        if(argc==4 || argc==5){
            if(read_and_validate_encode_args(argv,&encInfo)==e_success){
                printf("INFO : READ AND VALIDATE SUCCESS\n");
                printf("******* Encoding process statred *******\n");
                if(do_encoding(&encInfo)==e_success)
                {
                    printf("Encoding completed\n");
                }
                else
                {
                    printf("Encoding failed\n");
                    return 1;
                }
            }
            else{
                printf("ERROR : Read and validate failure\n");
                return 1;
            }
        }
        else{
            printf("%s Encoding %s -e <.bmp file> <.txt file> [output file]\n",argv[0],argv[0]);
        }
    }
    else if(check_operation_type(argv)== e_decode){
        printf("Selected decoding\n");
        //structure for decoding
        DecodeInfo decInfo;
        if(argc==3 || argc==4){
            if(read_and_validate_decode_args(argv,&decInfo)==e_success){
                printf("INFO : READ AND VALIDATE SUCCESS\n");
                printf("******* Decoding process statred *******\n");
                if(do_decoding(&decInfo)==e_success)
                {
                    printf("Decoding completed\n");
                }
                else
                {
                    printf("Decoding failed\n");
                    return 1;
                }
            }
            else
            {
                printf("ERROR : Read and validate failure\n");
                return 1;
            }
        }
        else{
            printf("%s Decoding %s -e <.bmp file> [output file]\n",argv[0],argv[0]);
        }
    }
    else{
        printf("unsupported\n");
        printf("%s Encoding %s -e <.bmp file> <.txt file> [output file]\n",argv[0],argv[0]);
        printf("%s Decoding %s -e <.bmp file> [output file]\n",argv[0],argv[0]);
    }
    return 0;
}

