#include <stdio.h>
#include <string.h>
#include "encode.h"
#include "types.h"
#include "common.h"

/* Function Definitions */

/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    // Seek to 18th byte
    fseek(fptr_image, 18, SEEK_SET);

    // Read the width (an int)
    fread(&width, sizeof(int), 1, fptr_image);
    //printf("width = %u\n", width);

    // Read the height (an int)
    fread(&height, sizeof(int), 1, fptr_image);
    //printf("height = %u\n", height);

    // Return image capacity
    return width * height * 3;
}

/* 
 * Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file and
 * Stego Image file
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors
 */
Status open_files(EncodeInfo *encInfo)
{
    // Src Image file
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r");
    // Do Error handling
    if (encInfo->fptr_src_image == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);

    	return e_failure;
    }

    // Secret file
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    // Do Error handling
    if (encInfo->fptr_secret == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);

    	return e_failure;
    }

    // Stego Image file
    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "w");
    // Do Error handling
    if (encInfo->fptr_stego_image == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);

    	return e_failure;
    }

    // No failure return e_success
    return e_success;
}

OperationType check_operation_type(char *argv[])
{
    //check for encode operation
    if(strcmp(argv[1], "-e") == 0)
           return e_encode;

    //check for decode operation
    else if(strcmp(argv[1], "-d") == 0)
           return e_decode;
    else
           e_unsupported;
}

Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
    //check for encode arguments
    if(argv[2] == NULL || argv[3]== NULL)
        return e_failure;

    if(strstr(argv[2],".bmp"))
        encInfo -> src_image_fname = argv[2];
    else
        return e_failure;

    if(strstr(argv[3], ".txt"))
        encInfo -> secret_fname = argv[3];
    else
        return e_failure;

    if(argv[4] == NULL)
        encInfo -> stego_image_fname = "stego.bmp";
    else
        encInfo -> stego_image_fname = argv[4];

    return e_success;
}

//function for file size
long get_file_size(FILE *fptr)
{
    fseek(fptr, 0, SEEK_END);
    return ftell(fptr);
}

/*Checking whether the capacity is sufficient or not*/
Status check_capacity(EncodeInfo *encInfo)
{
    //source image file size check for encoding data
    encInfo -> image_capacity = get_image_size_for_bmp(encInfo -> fptr_src_image);
    encInfo -> size_secret_file = get_file_size(encInfo -> fptr_secret);

    if(encInfo -> image_capacity > (16 + 32 + 32 + 32 + (encInfo -> size_secret_file)))
       return e_success;
    else
       return e_failure;
}

/* Copy bmp header to destination file */
Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image)
{
    //copying header data of 54 bytes to stego image
    fseek(fptr_src_image, 0, SEEK_SET);
    char str[54];

    fread(str, 54, 1,fptr_src_image);
    fwrite(str, 54, 1, fptr_dest_image);

    return e_success;
}

/* encoding byte to lsb */
Status encode_byte_to_lsb(char data, char *image_buffer)
{
    for(int i = 0; i < 8; i++)
    {
        image_buffer[i] = (image_buffer[i] & 0xFE) | (data >> (7 - i) & 1);
    }
    return e_success;

}

Status encode_data_to_image(char *data, int size, EncodeInfo *encInfo)
{
    for(int i = 0; i < size; i++)
    {
        fread(encInfo -> image_data, 8, 1, encInfo -> fptr_src_image);
        encode_byte_to_lsb(data[i], encInfo -> image_data);
        fwrite(encInfo -> image_data, 8, 1, encInfo -> fptr_stego_image);
    }
    return e_success;
}

Status encode_magic_string(char *magic_string, EncodeInfo *encInfo)
{
    //encoding magic string
    encode_data_to_image(magic_string, strlen(magic_string), encInfo);
    return e_success;

}

Status encode_size_to_lsb(int size, EncodeInfo *encInfo)
{
    //encoding secret file size
    char str[32];

    fread(str, 32, 1, encInfo -> fptr_src_image);

    for(int i=0; i<32 ; i++)
    {
        str[i] = (str[i] & 0xFE) | (size >> (31 - i) & 1);
    }

    fwrite(str, 32, 1, encInfo -> fptr_stego_image);
    return e_success;
}


Status encode_extn_size(int size, EncodeInfo *encInfo)
{
    //encoding extension size
    encode_size_to_lsb(size, encInfo);
    return e_success;
}

Status encode_secret_file_extn(char *file_extn, EncodeInfo *encInfo)
{
    //encoding secret file extension
    encode_data_to_image(file_extn, strlen(file_extn), encInfo);
    return e_success;

}

Status encode_secret_file_size(int file_size, EncodeInfo *encInfo)
{
    encode_size_to_lsb(file_size, encInfo);
        return e_success;
}

Status encode_secret_file_data(EncodeInfo *encInfo)
{
    //encoding secret file data to image using file pointers
    fseek(encInfo -> fptr_secret, 0,SEEK_SET);

    char str[encInfo -> size_secret_file];

    fread(str, encInfo -> size_secret_file, 1, encInfo -> fptr_secret);

    encode_data_to_image(str, encInfo -> size_secret_file, encInfo);

    return e_success;
}

Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest)
{
    char ch;
    //copying remaining data character by character
    while(fread(&ch, 1, 1, fptr_src) > 0)
    {
        fwrite(&ch, 1, 1, fptr_dest);
    }

    return e_success;
}

//function to close files
Status closing_encode_files(EncodeInfo *encInfo)
{
   fclose(encInfo->fptr_src_image);
   fclose(encInfo->fptr_secret);
   fclose(encInfo->fptr_stego_image);
}

/* do_encoding function to call other functions for encoding operation */
Status do_encoding(EncodeInfo* encinfo)
{
    if(open_files(encinfo)==e_success)
    {
        printf("INFO: Open file success\n");
        if(check_capacity(encinfo)==e_success)
        {
            printf("INFO: check capacity success\n");
            if(copy_bmp_header(encinfo->fptr_src_image,encinfo->fptr_stego_image)==e_success)
            {
                printf("INFO: Header file copied successfully\n");
                if(encode_magic_string(MAGIC_STRING,encinfo)==e_success)
                {
                    printf("INFO: Encode Magic String Completed\n");
                    if(encode_extn_size(strlen(encinfo->extn_secret_file),encinfo)==e_success)
                    {
                        printf("INFO: Encode secret file extension size completed\n");
                        if(encode_secret_file_extn(encinfo->extn_secret_file,encinfo)==e_success)
                        {
                            printf("INFO: Encode secret file extension completed\n");
                            if(encode_secret_file_size(encinfo->size_secret_file,encinfo)==e_success)
                            {
                                printf("INFO: Encode secret file size completed\n");
                                if(encode_secret_file_data(encinfo)==e_success)
                                {
                                    printf("INFO: Encode secret file data completed\n");
                                    if(copy_remaining_img_data(encinfo->fptr_src_image,encinfo->fptr_stego_image)==e_success)
                                    {
                                        printf("INFO: Copy remaining data successfull\n");
                                        return e_success;
                                    }
                                    else
                                    {
                                        printf("ERROR: Failed to copy remaining data\n");
                                        return e_failure;
                                    }
                                }
                                else
                                {
                                    printf("ERROR: Failed to encode secret file data\n");
                                    return e_failure;
                                }
                            }  
                            else
                            {
                                printf("ERROR: Failed to encode secret file size\n");
                                return e_failure;
                            }
                        }
                        else
                        {
                            printf("ERROR: Failed to encode secret file extension\n");
                            return e_failure;
                        }
                    }
                    else
                    {
                        printf("ERROR: Failed to encode secret file extension size\n");
                        return e_failure;
                    }
                }
                else
                {
                    printf("ERROR: Failed to encode magic string\n");
                    return e_failure;
                }
            }
            else
            {
                printf("ERROR: Failed to copy bmp header\n");
                return e_failure;
            }
        }
        else
        {
            printf("check capacity failure\n");
            return e_failure;
        }
    }
    else
    {
        printf("Open file failure\n");
        return e_failure;
    }
}
